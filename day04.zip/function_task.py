# 함수를 선언하는데, 
# 숫자값 두 개를 전달 받아
# 그 합을 반환하는 함수 작성

# 작성한 함수 테스트 실행해보기
def test(num1, num2):
    result = num1 + num2
    return result

# 함수명: add
# 매개변수: num1, num2, num3
# 반환: 전달받은 세 변수의 합을 정수로 반환

if __name__ == "__main__":
    # result = test(13, num2=15)
    # print(result) # 28
    pass